from flask import Flask, render_template, jsonify, request
app=Flask(__name__)
SOS=[
{"id":"SOS-103","victim":"Rajesh","age":72,"people":1,"location":"Panipat Flood Zone","water":"High","medical":"Weakness","vulnerability":"Elderly","lat":29.3909,"lng":76.9635,"wait":18},
{"id":"SOS-104","victim":"Family of 4","age":"Mixed","people":4,"location":"Low-lying Residential Area","water":"Severe","medical":"One injured person","vulnerability":"Family","lat":29.382,"lng":76.975,"wait":12},
{"id":"SOS-105","victim":"Aman","age":24,"people":1,"location":"Moderate-risk Area","water":"Medium","medical":"None","vulnerability":"Adult","lat":29.401,"lng":76.95,"wait":7}]
def score(x):
 s={"Severe":30,"High":25,"Medium":15}.get(x["water"],5)+{"Elderly":25,"Family":18,"Adult":8}.get(x["vulnerability"],8)
 s+=18 if "injur" in x["medical"].lower() else (10 if x["medical"]!="None" else 0)
 s+=min(15,x["people"]*3)+min(12,x["wait"]//3); s=min(99,s)
 level="CRITICAL" if s>=80 else "HIGH" if s>=60 else "MEDIUM" if s>=40 else "LOW"
 return {"priority_score":s,"priority_level":level,"reason":f'{x["water"]} flood risk + {x["vulnerability"].lower()} vulnerability + {x["medical"].lower()}',"recommended_action":"Dispatch nearest available responder immediately." if level in ("CRITICAL","HIGH") else "Monitor and queue for response.","recommended_responder":"R-01"}
@app.get("/")
def home(): return render_template("index.html")
@app.get("/api/sos")
def get(): return jsonify([{**x,"ai":score(x)} for x in SOS])
@app.post("/api/analyze")
def analyze():
 items=request.get_json().get("sos",SOS); out=[{**x,"ai":score(x)} for x in items]
 return jsonify({"mode":"DEMO MODE — SIMULATED AI","sos":sorted(out,key=lambda x:x["ai"]["priority_score"],reverse=True)})
@app.post("/api/dispatch")
def dispatch(): return jsonify({"success":True,"message":f'Responder R-01 assigned to {request.get_json().get("sos_id","SOS")} (simulated).'})
if __name__=="__main__": app.run(debug=True)
